# Amplicomsat
Processes microsatellite genotypes from Amplicon generated fastq read files
