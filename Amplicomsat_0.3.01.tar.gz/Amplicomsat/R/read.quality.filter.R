read.quality.filter<-function(sampleDir="./samples",Phred.treshold=30,All.below.Q=5,filterDir="samplesF"){

PhredString<-"+,-./0123456789:;<=>?@ABCDEFGHI" #Minimum quality allowed is 10

PhredString.T<-paste0("[^",substr(PhredString,start=Phred.treshold-9, stop=nchar(PhredString)),"]+")


system2(command="mkdir",args=filterDir)
files<-list.files(sampleDir)
pdf(file="Distribution of bases below Q threshold quality.pdf")
for(f in 1:length(files)){
  sampleTest<-readLines(paste0(sampleDir,"/",files[f]))
  if(length(sampleTest)==0)next
  sampleTest[seq(4,length(sampleTest),4)]

  QualitySearch<-grep(sampleTest[seq(4,length(sampleTest),4)],pattern=PhredString.T)
  QualitySearch<-lapply(strsplit(sampleTest[seq(4,length(sampleTest),4)],split=""),
  		function(x){grepl(x,pattern=PhredString.T)})
  
  hist(QualitySearch.SUM,breaks=c(0:max(QualitySearch.SUM)),xlim=c(0,20),
  	xlab="Number of bases below Q threshold quality",
  	main=paste0(files[f]," Q threshold: ",Phred.treshold))
  
  QualitySearch.SUM<-sapply(QualitySearch,sum)
  QualitySearch.R<-which(QualitySearch.SUM>All.below.Q)
 
  
  QR2remove<-QualitySearch.R*4
  QR2removeALL<-c(QR2remove-3,QR2remove-2,QR2remove-1,QR2remove)
  sampleTestF<-sampleTest[-QR2removeALL]
  readr::write_lines(sampleTestF,file=paste0("./",filterDir,"/",sub(".fastq",".F.fastq",files[f])))
  print(paste0("Filtered file ", files[f]," - ",length(QualitySearch.R)," reads removed"))
  readr::write_lines(paste0(files[f]," - ",length(QualitySearch.R),"(",round((length(QualitySearch.R)/(length(sampleTest)/4)*100),2),"%) reads removed")
              ,append = T,file="FilterLog")
  }
  dev.off()
}

